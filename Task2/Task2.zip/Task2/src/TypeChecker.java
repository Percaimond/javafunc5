public class TypeChecker {

    private ExprPLParser.ExprContext tree;

    public TypeChecker(ExprPLParser.ExprContext tree) {
        this.tree = tree;
    }

    public boolean check() {
        // TODO: implement
        return false;
    }

}
